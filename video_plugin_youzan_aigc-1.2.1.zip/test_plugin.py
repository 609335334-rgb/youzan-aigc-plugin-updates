# -*- coding: utf-8 -*-
"""AIGC 创作站插件契约测试（使用本地模拟网关，不发起真实网络请求）。"""
import base64
import contextlib
import io
import json
import os
import sys
import tempfile
import time
import unittest
import zipfile
from pathlib import Path
from unittest import mock


PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
PLUGINS_ROOT = os.path.dirname(os.path.dirname(PLUGIN_DIR))
sys.path.insert(0, PLUGIN_DIR)
sys.path.insert(0, PLUGINS_ROOT)

import main as plugin  # noqa: E402


MP4_SAMPLE = b"\x00\x00\x00\x18ftypisom\x00\x00\x02\x00isomiso2" + b"\x00" * 2048


def _next_version(version, steps=1):
    parts = [int(part) for part in str(version).split(".")]
    parts.extend([0] * (3 - len(parts)))
    parts[-1] += steps
    return ".".join(str(part) for part in parts)


class FakeResponse:
    def __init__(self, status_code=200, json_data=None, content=b""):
        self.status_code = status_code
        self._json_data = json_data
        self.content = content
        self.text = content.decode("utf-8", errors="replace") or json.dumps(json_data, ensure_ascii=False)

    def json(self):
        if self._json_data is None:
            raise ValueError("not JSON")
        return self._json_data


class FakeStreamResponse:
    """模拟 requests.get(stream=True) 的响应（更新包下载用）。"""

    def __init__(self, content, status_code=200):
        self.status_code = status_code
        self.content = content

    def iter_content(self, chunk_size=8192):
        yield self.content

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


def _make_update_package(version, main_text=None, entries=None):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        archive.writestr(
            "main.py",
            main_text if main_text is not None else 'PLUGIN = True\n_PLUGIN_VERSION = "%s"\n' % version,
        )
        archive.writestr("info.json", json.dumps({"version": version}, ensure_ascii=False))
        archive.writestr("ui/index.html", "<html>new %s</html>" % version)
        for name, data in (entries or {}).items():
            archive.writestr(name, data)
    return buffer.getvalue()


def make_context(**overrides):
    context = {
        "prompt": "测试视频提示词",
        "project_path": tempfile.mkdtemp(prefix="aigc_test_"),
        "viewer_index": 3,
        "unique_name": "shot001",
        "generation_round": 0,
        "output_position": [0],
        "scene_duration": 5,
        "first_frame_path": None,
        "reference_images": {},
        "plugin_params": {
            "api_key": "u_test_key",
            "base_url": "https://youzan666.vip",
            "model": "test-video-model",
            "generation_mode": plugin.MODE_AUTO,
            "resolution": "720p",
            "ratio": "16:9",
            "duration": "5",
            "timeout": 30,
            "poll_interval": 10,
            "max_poll_attempts": 10,
        },
    }
    context.update(overrides)
    return context


def media_urls(payload, media_type):
    return [
        item.get("url")
        for item in (payload.get("input", {}).get("media", []) or [])
        if isinstance(item, dict) and item.get("type") == media_type
    ]


class PluginApiTest(unittest.TestCase):
    def _successful_gateway(self, task_id="task_1", payload=None):
        payload = payload if payload is not None else {}

        def post(url, **kwargs):
            payload.update(kwargs["json"])
            return FakeResponse(202, {"taskId": task_id, "status": "processing"})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        return post, get

    def test_metadata_and_defaults(self):
        self.assertEqual(plugin._PLUGIN_VERSION, "1.2.1")
        self.assertEqual(plugin._default_params["poll_interval"], 10)
        self.assertEqual(
            plugin._default_params["update_manifest_url"],
            plugin._DEFAULT_UPDATE_MANIFEST_URL,
        )
        self.assertEqual(len(plugin._DEFAULT_UPDATE_MANIFEST_URLS), 2)
        self.assertEqual(plugin.MAX_IMAGE_REFS, 10)

    def test_base_url_normalization(self):
        self.assertEqual(plugin._normalize_base_url("https://youzan666.vip/v1/"), "https://youzan666.vip")
        self.assertEqual(
            plugin._normalize_base_url("https://youzan666.vip/api/v1/"),
            "https://youzan666.vip",
        )

    def test_dashscope_media_request_is_explicit_and_slot_ordered(self):
        payload = {
            "model": "wan3.0-video",
            "prompt": "@图片1 @图片2 @音频1",
            "duration": 5,
            "resolution": "720p",
            "ratio": "16:9",
            "reference_image": [
                "https://cdn.example.com/character.jpg",
                "https://cdn.example.com/location.jpg",
            ],
            "reference_audio": ["https://cdn.example.com/voice.mp3"],
            "reference_video": [],
        }
        plugin._validate_prompt_reference_slots(payload["prompt"], payload)
        media = plugin._build_dashscope_media(payload)
        plugin._validate_dashscope_media(payload, media)
        self.assertEqual(
            media,
            [
                {"type": "reference_image", "url": "https://cdn.example.com/character.jpg"},
                {"type": "reference_image", "url": "https://cdn.example.com/location.jpg"},
                {"type": "reference_audio", "url": "https://cdn.example.com/voice.mp3"},
            ],
        )
        body = plugin._build_dashscope_request_body(payload, media)
        self.assertEqual(body["input"]["media"], media)
        self.assertEqual(body["parameters"]["resolution"], "720P")

        interleaved = plugin._build_dashscope_media(
            payload,
            "@图片1 @音频1 @图片2",
        )
        self.assertEqual(
            [item["type"] for item in interleaved],
            ["reference_image", "reference_audio", "reference_image"],
        )
        plain_labels = plugin._build_dashscope_media(
            payload,
            "图2是场景，图1是角色，音频1是声音",
        )
        self.assertEqual(
            [item["type"] for item in plain_labels],
            ["reference_image", "reference_image", "reference_audio"],
        )

    def test_dashscope_task_response_helpers(self):
        response = {
            "output": {
                "task_id": "wan3_task",
                "task_status": "SUCCEEDED",
                "video_url": "https://cdn.example.com/result.mp4",
            }
        }
        self.assertEqual(plugin._extract_task_id(response), "wan3_task")
        self.assertEqual(plugin._extract_task_status(response), "succeeded")
        self.assertEqual(
            plugin._extract_video_url(response),
            "https://cdn.example.com/result.mp4",
        )

    def test_update_check_requires_strictly_newer_version(self):
        manifest = {"plugins": [{
            "plugin_id": plugin._PLUGIN_ID,
            "version": plugin._PLUGIN_VERSION,
            "download_url": "https://updates.example.com/plugin.zip",
        }]}
        with mock.patch("main.get_params", return_value={"update_manifest_url": "https://updates.example.com/manifest.json"}), \
             mock.patch("main.requests.get", return_value=FakeResponse(200, manifest)):
            result = plugin._check_update_available()
        self.assertTrue(result["ok"])
        self.assertFalse(result["has_update"])

    def test_update_check_falls_back_to_fixed_manifest(self):
        manifest = {"plugins": [{
            "plugin_id": plugin._PLUGIN_ID,
            "version": plugin._PLUGIN_VERSION,
            "download_url": "https://updates.example.com/plugin.zip",
        }]}
        with mock.patch("main.get_params", return_value={"update_manifest_url": ""}), \
             mock.patch("main.requests.get", return_value=FakeResponse(200, manifest)) as request_mock:
            result = plugin._check_update_available()
        self.assertTrue(result["ok"])
        self.assertEqual(
            request_mock.call_args_list[0].args[0],
            plugin._DEFAULT_UPDATE_MANIFEST_URL,
        )

    def test_update_check_returns_verified_download_details(self):
        manifest = {"plugins": [{
            "plugin_id": plugin._PLUGIN_ID,
            "version": _next_version(plugin._PLUGIN_VERSION),
            "download_url": "https://updates.example.com/plugin.zip",
            "sha256": "abc123",
            "changelog": "修复上传",
        }]}
        with mock.patch("main.get_params", return_value={"update_manifest_url": "https://updates.example.com/manifest.json"}), \
             mock.patch("main.requests.get", return_value=FakeResponse(200, manifest)):
            result = plugin._check_update_available()
        self.assertTrue(result["has_update"])
        self.assertEqual(result["download_url"], "https://updates.example.com/plugin.zip")
        self.assertEqual(result["sha256"], "abc123")

    def test_update_check_uses_highest_version_across_fixed_sources(self):
        older = {"plugins": [{
            "plugin_id": plugin._PLUGIN_ID,
            "version": plugin._PLUGIN_VERSION,
            "download_url": "https://updates.example.com/older.zip",
        }]}
        newer = {"plugins": [{
            "plugin_id": plugin._PLUGIN_ID,
            "version": _next_version(plugin._PLUGIN_VERSION),
            "download_url": "https://updates.example.com/newer.zip",
            "sha256": "def456",
        }]}

        def get(url, **kwargs):
            if "raw.githubusercontent.com" in url:
                return FakeResponse(200, newer)
            return FakeResponse(200, older)

        with mock.patch("main.get_params", return_value={"update_manifest_url": ""}), \
             mock.patch("main.requests.get", side_effect=get):
            result = plugin._check_update_available()
        self.assertTrue(result["has_update"])
        self.assertEqual(result["remote_version"], _next_version(plugin._PLUGIN_VERSION))
        self.assertEqual(result["download_url"], "https://updates.example.com/newer.zip")
        self.assertIn("raw.githubusercontent.com", result["manifest_url"])

    def test_task_id_response_uses_documented_status_endpoint(self):
        seen_urls = []

        def post(url, **kwargs):
            return FakeResponse(202, {"taskId": "doc_task"})

        def get(url, **kwargs):
            seen_urls.append(url)
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith("/v1/videos/doc_task") or url.endswith("/api/v1/tasks/doc_task"):
                return FakeResponse(200, {"status": "succeeded", "result": {"url": "https://cdn.example.com/result.mp4"}})
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            result = plugin.generate(make_context())

        self.assertTrue(os.path.exists(result[0]))
        self.assertEqual(seen_urls[0], "https://youzan666.vip/v1/videos/doc_task")

    def test_poll_interval_is_clamped_to_ten_seconds(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        context = make_context()
        context["plugin_params"]["poll_interval"] = 1
        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep") as sleep:
            plugin.generate(context)
        sleep.assert_called_with(10)

    def test_collects_ten_image_references(self):
        context = make_context(reference_images={index: f"https://cdn.example.com/{index}.jpg" for index in range(12)})
        self.assertEqual(len(plugin._collect_image_references(context)), 10)

    def test_string_reference_keys_keep_numeric_order(self):
        values = {str(index): f"https://cdn.example.com/{index}.jpg" for index in range(12)}
        ordered = plugin._collect_image_references(make_context(reference_images=values))
        self.assertEqual(ordered[:3], [
            "https://cdn.example.com/0.jpg",
            "https://cdn.example.com/1.jpg",
            "https://cdn.example.com/2.jpg",
        ])

    def test_reference_items_are_canonical_per_media_type(self):
        context = make_context(
            reference_images={0: "https://cdn.example.com/wrong-image.jpg"},
            reference_audios={0: "https://cdn.example.com/wrong-audio.mp3"},
            reference_items=[
                {"path": "https://cdn.example.com/character.jpg", "media_type": "image"},
                {"path": "https://cdn.example.com/voice-a.mp3", "media_type": "audio"},
                {"path": "https://cdn.example.com/location.jpg", "media_type": "image"},
                {"path": "https://cdn.example.com/voice-b.mp3", "media_type": "audio"},
            ],
        )
        self.assertEqual(plugin._collect_image_references(context), [
            "https://cdn.example.com/character.jpg",
            "https://cdn.example.com/location.jpg",
        ])
        self.assertEqual(plugin._collect_storyboard_audios(context), [
            "https://cdn.example.com/voice-a.mp3",
            "https://cdn.example.com/voice-b.mp3",
        ])

    def test_reference_slot_plan_freezes_independent_image_audio_slots(self):
        plan = plugin._build_reference_slot_plan(
            [
                "https://cdn.example.com/image-1.jpg",
                "https://cdn.example.com/image-2.jpg",
            ],
            [
                "https://cdn.example.com/audio-1.mp3",
                "https://cdn.example.com/audio-2.mp3",
            ],
        )
        self.assertEqual([item["slot"] for item in plan["images"]], [1, 2])
        self.assertEqual([item["slot"] for item in plan["audios"]], [1, 2])
        self.assertEqual(plan["images"][0]["transport"], "https_url")

    def test_reference_slot_plan_rejects_duplicate_and_opaque_asset_id(self):
        with self.assertRaisesRegex(Exception, "相同素材来源"):
            plugin._build_reference_slot_plan(
                [
                    "https://cdn.example.com/same.jpg",
                    "https://cdn.example.com/same.jpg",
                ],
                [],
            )
        with self.assertRaisesRegex(Exception, "不透明素材 ID"):
            plugin._build_reference_slot_plan(["asset_123"], [])

    def test_reference_slot_plan_rejects_insecure_http_url(self):
        with self.assertRaisesRegex(Exception, "不安全的 HTTP URL"):
            plugin._build_reference_slot_plan(["http://cdn.example.com/ref.jpg"], [])

    def test_reference_slot_plan_detects_processing_slot_loss(self):
        plan = plugin._build_reference_slot_plan(
            ["https://cdn.example.com/ref.jpg"],
            ["https://cdn.example.com/voice.mp3"],
        )
        with self.assertRaisesRegex(Exception, "素材槽位在处理过程中发生变化"):
            plugin._validate_reference_slot_plan(
                plan,
                {"reference_image": [], "reference_audio": ["https://cdn.example.com/voice.mp3"]},
            )

    def test_short_audio_fails_without_shifting_later_slot(self):
        paths = []
        for index in range(2):
            path = os.path.join(tempfile.mkdtemp(), f"voice{index}.mp3")
            with open(path, "wb") as file_obj:
                file_obj.write(b"audio")
            paths.append(path)
        with mock.patch("main._probe_media_duration", side_effect=[0.4, 4.0]), \
             mock.patch("main._upload_media_to_uguu") as upload:
            with self.assertRaisesRegex(Exception, "音频1"):
                plugin._prepare_audio_references(paths, timeout=30, segment_limit=5)
        upload.assert_not_called()

    def test_prompt_reference_slots_are_checked_before_submit(self):
        with self.assertRaisesRegex(Exception, "图片2"):
            plugin._validate_prompt_reference_slots(
                "图片1是角色，图片2是场景，音频1是声音",
                {"reference_image": ["https://cdn.example.com/one.jpg"],
                 "reference_audio": ["https://cdn.example.com/voice.mp3"]},
            )

    def test_plain_prompt_labels_work_without_at_and_do_not_require_description_order(self):
        prompt = "图2是场景，图1是角色，音频1是声音"
        self.assertEqual(
            plugin._prompt_reference_mentions(prompt),
            [("image", 2), ("image", 1), ("audio", 1)],
        )
        plugin._validate_prompt_reference_slots(
            prompt,
            {
                "reference_image": [
                    "https://cdn.example.com/character.jpg",
                    "https://cdn.example.com/scene.jpg",
                ],
                "reference_audio": ["https://cdn.example.com/voice.mp3"],
            },
        )

    def test_local_image_is_sent_as_base64_without_upload(self):
        from PIL import Image

        image_path = os.path.join(tempfile.mkdtemp(), "reference.jpg")
        Image.new("RGB", (16, 16), (10, 20, 30)).save(image_path)
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        context = make_context(reference_images={0: image_path})
        with mock.patch("main.requests.post", side_effect=post) as post_mock, \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)

        self.assertTrue(media_urls(payload, "reference_image")[0].startswith("data:image/jpeg;base64,"))
        self.assertEqual(post_mock.call_count, 1)

    def test_transparent_png_is_flattened_onto_white_not_black(self):
        from PIL import Image

        image_path = os.path.join(tempfile.mkdtemp(), "transparent.png")
        Image.new("RGBA", (32, 32), (0, 0, 0, 0)).save(image_path)
        flattened = plugin._flatten_to_rgb(Image.open(image_path))
        self.assertEqual(flattened.mode, "RGB")
        self.assertEqual(flattened.getpixel((5, 5)), (255, 255, 255))

    def test_16bit_png_is_normalized_instead_of_clipped(self):
        from PIL import Image

        image = Image.new("I;16", (256, 1))
        for index in range(256):
            image.putpixel((index, 0), index * 257)
        flattened = plugin._flatten_to_rgb(image)
        self.assertEqual(flattened.getpixel((0, 0)), 0)
        self.assertLessEqual(abs(flattened.getpixel((128, 0)) - 128), 2)
        self.assertGreaterEqual(flattened.getpixel((255, 0)), 253)

    def test_animated_png_keeps_only_first_frame(self):
        from PIL import Image

        image_path = os.path.join(tempfile.mkdtemp(), "animated.png")
        frames = [
            Image.new("RGBA", (20, 20), (255, 0, 0, 255)),
            Image.new("RGBA", (20, 20), (0, 0, 255, 255)),
        ]
        frames[0].save(image_path, "PNG", save_all=True, append_images=frames[1:], duration=100, loop=0)
        rendered = Image.open(plugin._preprocess_reference_image(image_path))
        red, green, blue = rendered.getpixel((10, 10))
        self.assertGreater(red, 200)
        self.assertLess(green, 60)
        self.assertLess(blue, 60)

    def test_png_reference_is_sent_as_base64_without_upload(self):
        from PIL import Image

        image_path = os.path.join(tempfile.mkdtemp(), "reference.png")
        Image.new("RGBA", (16, 16), (10, 20, 30, 255)).save(image_path)
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        context = make_context(reference_images={0: image_path})
        with mock.patch("main.requests.post", side_effect=post) as post_mock, \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)
        self.assertTrue(media_urls(payload, "reference_image")[0].startswith("data:image/jpeg;base64,"))
        self.assertEqual(post_mock.call_count, 1)

    def test_png_renamed_as_jpg_is_converted_without_error(self):
        from PIL import Image

        image_path = os.path.join(tempfile.mkdtemp(), "disguised.jpg")
        Image.new("RGB", (16, 16), (10, 20, 30)).save(image_path, "PNG")
        resolved = plugin._resolve_reference_image_url(image_path)
        self.assertTrue(resolved.startswith("data:image/jpeg;base64,"))

    def test_jpeg_data_uri_reference_passes_through(self):
        data_uri = "data:image/jpeg;base64," + base64.b64encode(b"jpeg").decode("ascii")
        self.assertEqual(plugin._resolve_reference_image_url(data_uri), data_uri)

    def test_oversized_jpg_reference_is_downscaled_to_2048(self):
        from PIL import Image

        image_path = os.path.join(tempfile.mkdtemp(), "big.jpg")
        Image.new("RGB", (3000, 1200), (10, 20, 30)).save(image_path)
        resolved = plugin._resolve_reference_image_url(image_path)
        self.assertTrue(resolved.startswith("data:image/jpeg;base64,"))
        self.assertFalse(os.path.exists(image_path + "_preprocessed.jpg"))

    def test_local_audio_is_uploaded_before_submission(self):
        audio_path = os.path.join(tempfile.mkdtemp(), "voice.mp3")
        with open(audio_path, "wb") as file_obj:
            file_obj.write(b"audio")
        context = make_context(reference_audios={0: audio_path})
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        with mock.patch("main._upload_media_to_uguu", return_value="https://n.uguu.se/voice.mp3") as upload, \
             mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)
        upload.assert_called_once_with(audio_path, timeout=30)
        self.assertEqual(media_urls(payload, "reference_audio"), ["https://n.uguu.se/voice.mp3"])

    def test_audio_upload_action_uses_uguu(self):
        encoded = base64.b64encode(b"audio").decode("ascii")
        with mock.patch("main._upload_media_to_uguu", return_value="https://n.uguu.se/voice.mp3"):
            result = plugin.handle_action("audio_upload", {"name": "voice.mp3", "base64": encoded})
        self.assertTrue(result["ok"])
        self.assertEqual(result["url"], "https://n.uguu.se/voice.mp3")

    def test_local_video_is_uploaded(self):
        video_path = os.path.join(tempfile.mkdtemp(), "reference.mp4")
        with open(video_path, "wb") as file_obj:
            file_obj.write(MP4_SAMPLE)
        with mock.patch("main._upload_media_to_uguu", return_value="https://n.uguu.se/reference.mp4") as upload:
            refs = plugin._collect_video_references(make_context(reference_videos=[video_path]), timeout=30)
        upload.assert_called_once_with(video_path, timeout=30)
        self.assertEqual(refs, ["https://n.uguu.se/reference.mp4"])

    def test_public_first_last_frames_use_official_fields(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        context = make_context(
            first_frame_path="https://cdn.example.com/first.png",
            end_frame_path="https://cdn.example.com/last.png",
        )
        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)

        self.assertEqual(media_urls(payload, "first_frame"), ["https://cdn.example.com/first.png"])
        self.assertEqual(media_urls(payload, "last_frame"), ["https://cdn.example.com/last.png"])
        self.assertEqual(media_urls(payload, "reference_image"), [])

    def test_failed_status_is_terminal(self):
        polls = []

        def post(url, **kwargs):
            return FakeResponse(202, {"taskId": "failed_task"})

        def get(url, **kwargs):
            polls.append(url)
            return FakeResponse(200, {"status": "failed", "error": {"message": "upstream failure"}})

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            with self.assertRaisesRegex(Exception, "视频任务失败"):
                plugin.generate(make_context())
        self.assertEqual(len(polls), 1)

    def test_public_audio_and_image_data_url_are_passed_through(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        data_image = "data:image/jpeg;base64," + base64.b64encode(b"jpeg").decode("ascii")
        context = make_context(reference_images={0: data_image})
        context["plugin_params"].update({
            "enable_audio_reference": True,
            "audio_reference_url": "https://cdn.example.com/voice.mp3",
        })
        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)
        self.assertEqual(media_urls(payload, "reference_image"), [data_image])
        self.assertEqual(media_urls(payload, "reference_audio"), ["https://cdn.example.com/voice.mp3"])


    def test_history_prompt_matching_tolerates_gateway_truncation(self):
        long_prompt = "分镜提示词：" + "镜头描述。" * 200
        truncated = long_prompt[:500]
        self.assertTrue(plugin._prompt_matches_history(truncated, long_prompt))
        self.assertTrue(plugin._prompt_matches_history(long_prompt, long_prompt))
        self.assertTrue(plugin._prompt_matches_history("资产映射：\r\n出镜人物：甲", "资产映射：\n出镜人物：甲"))
        self.assertFalse(plugin._prompt_matches_history(truncated, "完全不同的分镜" + long_prompt))
        self.assertFalse(plugin._prompt_matches_history("太短", "太短" + "x" * 100))

    def test_submit_timeout_recovers_task_from_truncated_history(self):
        long_prompt = "多场景，资产映射：\n出镜人物：马会珍@图片1。\n" + "镜头1 景别：中近景。" * 120
        self.assertGreater(len(long_prompt), 500)
        task_id = "wan3_recovered_task"
        posts = []
        polls = []

        def post(url, **kwargs):
            posts.append(kwargs["json"])
            return FakeResponse(504, None)

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {
                    "tasks": [{
                        "id": task_id,
                        "type": "video",
                        "model": "test-video-model",
                        "modelName": "test-video-model",
                        "prompt": long_prompt[:500],
                        "status": "processing",
                        "createdAt": int(time.time() * 1000),
                    }],
                    "hasMore": False,
                })
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                polls.append(url)
                return FakeResponse(200, {
                    "id": task_id,
                    "status": "success",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            files = plugin.generate(make_context(
                prompt=long_prompt,
                reference_images={0: "https://cdn.example.com/recovery-ref.jpg"},
            ))

        self.assertEqual(len(posts), 1)
        self.assertEqual(len(polls), 1)
        self.assertTrue(files[0].endswith(".mp4"))

    def test_recovery_gives_up_after_deadline_without_matching_task(self):
        ticks = {"now": 1000000.0}

        def fake_time():
            ticks["now"] += 60.0
            return ticks["now"]

        def post(url, **kwargs):
            return FakeResponse(504, None)

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"), \
             mock.patch("main.time.time", side_effect=fake_time):
            with self.assertRaisesRegex(Exception, "未找到匹配任务"):
                plugin.generate(make_context(prompt="测试视频提示词"))

    def test_success_falls_back_to_backup_url_when_primary_link_expires(self):
        task_id = "backup_task"
        media_requests = []

        def post(url, **kwargs):
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {
                        "url": "https://cdn.example.com/expired.mp4",
                        "backupUrl": "https://youzan666.vip/uploads/backup.mp4",
                    },
                })
            media_requests.append(url)
            if url.endswith("expired.mp4"):
                return FakeResponse(404, {"error": "link expired"})
            if url.endswith("backup.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            files = plugin.generate(make_context())

        self.assertEqual(media_requests, [
            "https://cdn.example.com/expired.mp4",
            "https://youzan666.vip/uploads/backup.mp4",
        ])
        with open(files[0], "rb") as file_obj:
            self.assertEqual(file_obj.read(), MP4_SAMPLE)

    def test_video_url_candidates_put_primary_link_before_backup(self):
        candidates = plugin._extract_video_url_candidates({
            "status": "succeeded",
            "result": {"url": "https://a.example.com/1.mp4", "backupUrl": "https://b.example.com/1.mp4"},
        })
        self.assertEqual(candidates, ["https://a.example.com/1.mp4", "https://b.example.com/1.mp4"])
        self.assertEqual(plugin._extract_video_url({"result": {"backup_url": "https://b.example.com/2.mp4"}}),
                         "https://b.example.com/2.mp4")
        self.assertEqual(plugin._extract_video_url({"status": "succeeded"}), None)

    def test_direct_url_is_accepted_as_video_link(self):
        data = {"status": "success", "result": {
            "type": "video",
            "directUrl": "https://dashscope.example.com/1.mp4?Expires=1789526309",
        }}
        self.assertEqual(plugin._extract_video_url_candidates(data),
                         ["https://dashscope.example.com/1.mp4?Expires=1789526309"])
        duplicated = {"result": {"url": "https://a.example.com/1.mp4", "directUrl": "https://a.example.com/1.mp4"}}
        self.assertEqual(plugin._extract_video_url_candidates(duplicated), ["https://a.example.com/1.mp4"])

    def test_submit_retries_when_import_concurrency_is_limited(self):
        attempts = {"count": 0}
        headers = []
        task_id = "busy_task"

        def post(url, **kwargs):
            attempts["count"] += 1
            headers.append(kwargs["headers"])
            if attempts["count"] == 1:
                return FakeResponse(429, {"code": "WAN3_API_IMPORT_BUSY"})
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep") as sleep:
            files = plugin.generate(make_context())

        self.assertEqual(attempts["count"], 2)
        self.assertTrue(os.path.exists(files[0]))
        self.assertIn(mock.call(4), sleep.call_args_list)
        self.assertEqual(headers[0]["Idempotency-Key"], headers[1]["Idempotency-Key"])

    def test_import_busy_queue_gives_up_after_deadline(self):
        attempts = {"count": 0}
        ticks = {"now": 1000000.0}

        def fake_time():
            ticks["now"] += 60.0
            return ticks["now"]

        def post(url, **kwargs):
            attempts["count"] += 1
            return FakeResponse(429, {"code": "WAN3_API_IMPORT_BUSY"})

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=lambda *args, **kwargs: self.fail("不应查询任务")), \
             mock.patch("main.time.sleep"), \
             mock.patch("main.time.time", side_effect=fake_time):
            with self.assertRaisesRegex(Exception, "WAN3_API_IMPORT_BUSY"):
                plugin.generate(make_context())

        # 排队窗口（600s，假时钟每次 +60s）内应重试多次，而不是一次就报错
        self.assertGreater(attempts["count"], 3)

    def test_media_submissions_never_reuse_gateway_conversation(self):
        reference_image = "https://cdn.example.com/ref.jpg"
        payloads = []
        task_ids = ["no_reuse_1", "no_reuse_2"]

        def post(url, **kwargs):
            payloads.append(dict(kwargs["json"]))
            return FakeResponse(202, {"taskId": task_ids[len(payloads) - 1], "conversationId": "conv_new"})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            for task_id in task_ids:
                if url.endswith("/v1/videos/" + task_id) or url.endswith("/api/v1/tasks/" + task_id):
                    return FakeResponse(200, {
                        "status": "succeeded",
                        "conversationId": "conv_new",
                        "result": {"url": "https://cdn.example.com/result.mp4"},
                    })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail("unexpected GET " + url)

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(make_context(reference_images={0: reference_image}))
            plugin.generate(make_context(reference_images={0: reference_image}))

        self.assertEqual(len(payloads), 2)
        for payload in payloads:
            self.assertNotIn("conversationId", payload)
            self.assertEqual(media_urls(payload, "reference_image"), [reference_image])
        self.assertFalse(hasattr(plugin, "_CONVERSATION_CACHE"))
        self.assertFalse(hasattr(plugin, "_media_signature"))

    def test_media_error_is_reported_without_conversation_retry(self):
        reference_image = "https://cdn.example.com/ref.jpg"
        attempts = {"count": 0}

        def post(url, **kwargs):
            attempts["count"] += 1
            return FakeResponse(400, {"code": "WAN3_API_PROMPT_INVALID"})

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=lambda *args, **kwargs: self.fail("不应查询任务")), \
             mock.patch("main.time.sleep"):
            with self.assertRaisesRegex(Exception, "WAN3_API_PROMPT_INVALID"):
                plugin.generate(make_context(reference_images={0: reference_image}))

        self.assertEqual(attempts["count"], 1)

    def test_import_busy_is_retried_even_when_gateway_answers_400(self):
        attempts = {"count": 0}
        task_id = "busy_task"

        def post(url, **kwargs):
            attempts["count"] += 1
            if attempts["count"] == 1:
                return FakeResponse(400, {"code": "WAN3_API_IMPORT_BUSY"})
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            files = plugin.generate(make_context())

        self.assertEqual(attempts["count"], 2)
        self.assertTrue(os.path.exists(files[0]))

    def _make_installed_plugin(self, version="1.0.0"):
        root = Path(tempfile.mkdtemp(prefix="zz_installed_"))
        (root / "ui").mkdir()
        (root / "main.py").write_text(
            'PLUGIN = True\n_PLUGIN_VERSION = "%s"\n' % version, encoding="utf-8"
        )
        (root / "info.json").write_text(json.dumps({"version": version}), encoding="utf-8")
        (root / "ui" / "index.html").write_text("<html>old</html>", encoding="utf-8")
        (root / "ui" / "legacy.html").write_text("legacy", encoding="utf-8")
        return root

    def test_update_install_replaces_files_and_keeps_backup(self):
        root = self._make_installed_plugin("1.0.0")
        package = _make_update_package("1.0.1")
        with mock.patch.object(plugin, "_PLUGIN_FILE", str(root / "main.py")), \
             mock.patch.object(plugin, "_PLUGIN_VERSION", "1.0.0"), \
             mock.patch("main.requests.get", return_value=FakeStreamResponse(package)):
            result = plugin.handle_action("do_update", {
                "download_url": "https://updates.example.com/plugin.zip",
                "remote_version": "1.0.1",
            })

        self.assertTrue(result["ok"], result)
        self.assertIn("1.0.1", result["message"])
        self.assertIn("请重启", result["message"])
        self.assertIn('_PLUGIN_VERSION = "1.0.1"', (root / "main.py").read_text(encoding="utf-8"))
        self.assertEqual(json.loads((root / "info.json").read_text(encoding="utf-8"))["version"], "1.0.1")
        self.assertIn("new 1.0.1", (root / "ui" / "index.html").read_text(encoding="utf-8"))
        self.assertFalse((root / "ui" / "legacy.html").exists())
        backups = list(root.glob("main.py.bak.*"))
        self.assertEqual(len(backups), 1)
        self.assertIn('_PLUGIN_VERSION = "1.0.0"', backups[0].read_text(encoding="utf-8"))

    def test_update_install_rejects_package_not_newer(self):
        root = self._make_installed_plugin("1.0.0")
        package = _make_update_package("1.0.0")
        with mock.patch.object(plugin, "_PLUGIN_FILE", str(root / "main.py")), \
             mock.patch.object(plugin, "_PLUGIN_VERSION", "1.0.0"), \
             mock.patch("main.requests.get", return_value=FakeStreamResponse(package)):
            result = plugin.handle_action("do_update", {
                "download_url": "https://updates.example.com/plugin.zip",
                "remote_version": "1.0.0",
            })

        self.assertFalse(result["ok"])
        self.assertIn("版本异常", result["error"])
        self.assertIn('_PLUGIN_VERSION = "1.0.0"', (root / "main.py").read_text(encoding="utf-8"))
        self.assertEqual(list(root.glob("main.py.bak.*")), [])

    def test_update_install_rejects_version_mismatch_with_manifest(self):
        root = self._make_installed_plugin("1.0.0")
        package = _make_update_package("1.0.1")
        with mock.patch.object(plugin, "_PLUGIN_FILE", str(root / "main.py")), \
             mock.patch.object(plugin, "_PLUGIN_VERSION", "1.0.0"), \
             mock.patch("main.requests.get", return_value=FakeStreamResponse(package)):
            result = plugin.handle_action("do_update", {
                "download_url": "https://updates.example.com/plugin.zip",
                "remote_version": "1.0.2",
            })

        self.assertFalse(result["ok"])
        self.assertIn("与更新清单不一致", result["error"])
        self.assertIn('_PLUGIN_VERSION = "1.0.0"', (root / "main.py").read_text(encoding="utf-8"))

    def test_update_install_rejects_package_without_version(self):
        root = self._make_installed_plugin("1.0.0")
        package = _make_update_package("1.0.1", main_text="PLUGIN = True\n")
        with mock.patch.object(plugin, "_PLUGIN_FILE", str(root / "main.py")), \
             mock.patch.object(plugin, "_PLUGIN_VERSION", "1.0.0"), \
             mock.patch("main.requests.get", return_value=FakeStreamResponse(package)):
            result = plugin.handle_action("do_update", {
                "download_url": "https://updates.example.com/plugin.zip",
            })

        self.assertFalse(result["ok"])
        self.assertIn("缺少版本号", result["error"])
        self.assertIn('_PLUGIN_VERSION = "1.0.0"', (root / "main.py").read_text(encoding="utf-8"))

    def test_update_install_rolls_back_all_replaced_files_on_failure(self):
        root = self._make_installed_plugin("1.0.0")
        package = _make_update_package("1.0.1", entries={"ui/extra.js": "new asset"})
        real_copytree = plugin.shutil.copytree
        calls = {"count": 0}

        def flaky_copytree(src, dst, **kwargs):
            calls["count"] += 1
            if calls["count"] == 2:
                raise OSError("磁盘写入失败")
            return real_copytree(src, dst, **kwargs)

        with mock.patch.object(plugin, "_PLUGIN_FILE", str(root / "main.py")), \
             mock.patch.object(plugin, "_PLUGIN_VERSION", "1.0.0"), \
             mock.patch("main.requests.get", return_value=FakeStreamResponse(package)), \
             mock.patch("main.shutil.copytree", side_effect=flaky_copytree):
            result = plugin.handle_action("do_update", {
                "download_url": "https://updates.example.com/plugin.zip",
                "remote_version": "1.0.1",
            })

        self.assertFalse(result["ok"], result)
        self.assertIn("磁盘写入失败", result["error"])
        self.assertIn('_PLUGIN_VERSION = "1.0.0"', (root / "main.py").read_text(encoding="utf-8"))
        self.assertEqual(json.loads((root / "info.json").read_text(encoding="utf-8"))["version"], "1.0.0")
        self.assertEqual((root / "ui" / "index.html").read_text(encoding="utf-8"), "<html>old</html>")
        self.assertEqual((root / "ui" / "legacy.html").read_text(encoding="utf-8"), "legacy")
        self.assertFalse((root / "ui" / "extra.js").exists())

    def test_api_error_hints_are_appended_for_documented_codes(self):
        described = plugin._describe_api_error('HTTP 429 - {"code": "WAN3_API_IMPORT_BUSY"}')
        self.assertTrue(described.startswith("HTTP 429 - "))
        self.assertIn("\n提示：", described)
        self.assertIn("并发超限", described)
        self.assertEqual(plugin._describe_api_error(described), described)
        self.assertEqual(plugin._describe_api_error("HTTP 500 - 未知错误"), "HTTP 500 - 未知错误")
        self.assertEqual(plugin._describe_api_error(None), "")
        self.assertIn("内容安全审核", plugin._describe_api_error("DataInspectionFailed"))

    def test_reference_image_log_is_truncated(self):
        data_image = "data:image/jpeg;base64," + "A" * 4000
        preview = plugin._preview_media(data_image)
        self.assertTrue(preview.startswith("data:image/jpeg;base64,"))
        self.assertLess(len(preview), 200)
        self.assertIn(f"{len(data_image)} 字符", preview)
        self.assertEqual(plugin._preview_media("https://cdn.example.com/ref.jpg"), "https://cdn.example.com/ref.jpg")
        self.assertEqual(plugin._preview_media([data_image, "abc"])[1], "abc")
        self.assertEqual(plugin._preview_media(None), "")

    def test_submit_sends_idempotency_key(self):
        seen = []
        task_id = "idem_task"

        def post(url, **kwargs):
            seen.append(kwargs["headers"])
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(make_context())

        key = seen[0]["Idempotency-Key"]
        self.assertTrue(key.startswith("zz-"))
        self.assertTrue(key.isascii())
        self.assertLessEqual(len(key), 128)

    def test_submit_busy_reason_classifies_gateway_limits(self):
        self.assertIn("素材导入并发", plugin._submit_busy_reason(
            FakeResponse(429, {"code": "WAN3_API_IMPORT_BUSY"})))
        self.assertIn("Token", plugin._submit_busy_reason(
            FakeResponse(429, {"code": "token_quota_exceeded"})))
        self.assertIn("视频生成并发", plugin._submit_busy_reason(
            FakeResponse(429, {"error": "concurrency limit reached"})))
        self.assertIn("限流", plugin._submit_busy_reason(
            FakeResponse(429, {"error": "too many requests"})))
        self.assertTrue(plugin._is_submit_busy(FakeResponse(429, {"error": "x"})))
        self.assertTrue(plugin._is_submit_busy(FakeResponse(400, {"code": "WAN3_API_IMPORT_BUSY"})))
        self.assertFalse(plugin._is_submit_busy(FakeResponse(400, {"code": "WAN3_API_PROMPT_INVALID"})))
        self.assertFalse(plugin._is_submit_busy(FakeResponse(504, None)))

    def test_media_submission_holds_one_import_slot(self):
        observed = []
        task_id = "slot_task"

        def post(url, **kwargs):
            observed.append(plugin._IMPORT_SEMAPHORE._value)
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        before = plugin._IMPORT_SEMAPHORE._value
        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(make_context(reference_images={0: "https://cdn.example.com/ref.jpg"}))

        self.assertEqual(observed, [before - 1])
        self.assertEqual(plugin._IMPORT_SEMAPHORE._value, before)

    def test_text_only_submission_does_not_take_import_slot(self):
        observed = []
        task_id = "text_task"

        def post(url, **kwargs):
            observed.append(plugin._IMPORT_SEMAPHORE._value)
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        before = plugin._IMPORT_SEMAPHORE._value
        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(make_context())

        self.assertEqual(observed, [before])

    def test_import_slot_wait_stops_at_deadline(self):
        held = []
        for _ in range(plugin.IMPORT_CONCURRENCY):
            self.assertTrue(plugin._IMPORT_SEMAPHORE.acquire(blocking=False))
            held.append(True)
        try:
            progress = []
            started = time.time()
            acquired = plugin._acquire_import_slot(time.time() + 1.1, cb=progress.append)
            elapsed = time.time() - started
        finally:
            for _ in held:
                plugin._IMPORT_SEMAPHORE.release()
        self.assertFalse(acquired)
        self.assertGreaterEqual(elapsed, 1.0)

    def test_reference_media_wins_over_first_last_frame(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        audio_path = os.path.join(tempfile.mkdtemp(), "voice.mp3")
        with open(audio_path, "wb") as file_obj:
            file_obj.write(b"audio")
        context = make_context(
            first_frame_path="https://cdn.example.com/first.png",
            end_frame_path="https://cdn.example.com/last.png",
            reference_images={0: "https://cdn.example.com/ref.jpg"},
            reference_audios={0: audio_path},
            reference_videos=["https://cdn.example.com/ref.mp4"],
        )
        # 官方万相3.0：首尾帧与参考素材互斥；本项目以参考图为主 -> 保留参考素材

        with mock.patch("main._upload_media_to_uguu", return_value="https://n.uguu.se/voice.mp3"), \
             mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)

        self.assertEqual(media_urls(payload, "reference_image"), ["https://cdn.example.com/ref.jpg"])
        self.assertEqual(media_urls(payload, "reference_video"), ["https://cdn.example.com/ref.mp4"])
        self.assertEqual(media_urls(payload, "reference_audio"), ["https://n.uguu.se/voice.mp3"])
        self.assertNotIn("first_frame", payload)
        self.assertNotIn("last_frame", payload)

    def test_reference_mode_keeps_reference_media_without_frames(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        context = make_context(
            reference_images={0: "https://cdn.example.com/ref.jpg"},
            reference_videos=["https://cdn.example.com/ref.mp4"],
        )
        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)

        self.assertEqual(media_urls(payload, "reference_image"), ["https://cdn.example.com/ref.jpg"])
        self.assertEqual(media_urls(payload, "reference_video"), ["https://cdn.example.com/ref.mp4"])
        self.assertNotIn("first_frame", payload)

    def test_audio_keep_seconds_enforces_official_limits(self):
        self.assertEqual(plugin._audio_keep_seconds(12.0, 0.0, 15, 15), 12.0)
        self.assertEqual(plugin._audio_keep_seconds(12.0, 12.0, 15, 15), 3.0)
        self.assertEqual(plugin._audio_keep_seconds(None, 0.0, 15, 15), 15)
        # 剩余额度不足官方单段下限 1 秒时，该段直接丢弃
        self.assertIsNone(plugin._audio_keep_seconds(None, 14.5, 15, 15))
        self.assertIsNone(plugin._audio_keep_seconds(None, 14.9, 15, 15))
        self.assertIsNone(plugin._audio_keep_seconds(0.4, 0.0, 15, 15))
        # 本镜只有 5 秒时，单段可用额度压到 5 秒
        self.assertEqual(plugin._audio_keep_seconds(12.0, 0.0, 5, 15), 5.0)

    def test_long_local_audio_is_trimmed_then_uploaded(self):
        audio_path = os.path.join(tempfile.mkdtemp(), "voice.mp3")
        with open(audio_path, "wb") as file_obj:
            file_obj.write(b"audio")
        trimmed_path = os.path.join(tempfile.mkdtemp(), "voice_trim.mp3")
        with mock.patch("main._probe_media_duration", return_value=12.0), \
             mock.patch("main._trim_media_file", return_value=trimmed_path) as trim, \
             mock.patch("main._upload_media_to_uguu", return_value="https://n.uguu.se/voice.mp3") as upload:
            urls = plugin._prepare_audio_references([audio_path], timeout=30, segment_limit=5)

        self.assertEqual(urls, ["https://n.uguu.se/voice.mp3"])
        trim.assert_called_once_with(audio_path, 5.0, timeout=30)
        upload.assert_called_once_with(trimmed_path, timeout=30)

    def test_short_local_audio_is_uploaded_as_is(self):
        audio_path = os.path.join(tempfile.mkdtemp(), "voice.mp3")
        with open(audio_path, "wb") as file_obj:
            file_obj.write(b"audio")
        with mock.patch("main._probe_media_duration", return_value=4.0), \
             mock.patch("main._trim_media_file") as trim, \
             mock.patch("main._upload_media_to_uguu", return_value="https://n.uguu.se/voice.mp3") as upload:
            urls = plugin._prepare_audio_references([audio_path], timeout=30, segment_limit=5)

        self.assertEqual(urls, ["https://n.uguu.se/voice.mp3"])
        trim.assert_not_called()
        upload.assert_called_once_with(audio_path, timeout=30)

    def test_audio_references_stop_at_total_budget(self):
        paths = []
        for index in range(4):
            path = os.path.join(tempfile.mkdtemp(), f"voice{index}.mp3")
            with open(path, "wb") as file_obj:
                file_obj.write(b"audio")
            paths.append(path)
        uploaded = []

        def fake_upload(path, timeout=60):
            uploaded.append(path)
            return f"https://n.uguu.se/{len(uploaded)}.mp3"

        with mock.patch("main._probe_media_duration", return_value=5.0), \
             mock.patch("main._trim_media_file", side_effect=lambda path, seconds, timeout=60: path), \
             mock.patch("main._upload_media_to_uguu", side_effect=fake_upload):
            with self.assertRaisesRegex(Exception, "音频4"):
                plugin._prepare_audio_references(paths, timeout=30, segment_limit=5)

        self.assertEqual(len(uploaded), 3)

    def test_audio_urls_pass_through_without_upload(self):
        with mock.patch("main._upload_media_to_uguu") as upload:
            urls = plugin._prepare_audio_references(
                ["https://cdn.example.com/1.mp3", "https://cdn.example.com/1.mp3",
                 "https://cdn.example.com/2.mp3"],
                timeout=30, segment_limit=5)
        # 重复 URL 也必须保留为两个槽位，避免音频2被音频3顶替。
        self.assertEqual(urls, [
            "https://cdn.example.com/1.mp3",
            "https://cdn.example.com/1.mp3",
            "https://cdn.example.com/2.mp3",
        ])
        upload.assert_not_called()

    def test_audio_trimming_uses_real_ffmpeg(self):
        import subprocess

        ffmpeg = plugin._find_ffmpeg()
        if not ffmpeg:
            self.skipTest("未找到 ffmpeg")
        source = os.path.join(tempfile.mkdtemp(), "tone.wav")
        subprocess.run([ffmpeg, "-y", "-f", "lavfi", "-i", "sine=frequency=440:duration=12",
                        "-ar", "16000", source], capture_output=True, timeout=60)
        if not os.path.exists(source):
            self.skipTest("ffmpeg 无法生成测试音频")

        self.assertGreater(plugin._probe_media_duration(source), 11.0)
        trimmed = plugin._trim_media_file(source, 5)
        self.assertNotEqual(trimmed, source)
        trimmed_duration = plugin._probe_media_duration(trimmed)
        self.assertIsNotNone(trimmed_duration)
        self.assertLessEqual(trimmed_duration, 5.5)

    def test_long_audio_reference_is_trimmed_before_submit(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        audio_paths = []
        for index in range(2):
            path = os.path.join(tempfile.mkdtemp(), f"voice{index}.mp3")
            with open(path, "wb") as file_obj:
                file_obj.write(b"audio")
            audio_paths.append(path)
        context = make_context(reference_audios={index: path for index, path in enumerate(audio_paths)})
        with mock.patch("main._upload_media_to_uguu",
                        side_effect=["https://n.uguu.se/1.mp3", "https://n.uguu.se/2.mp3"]), \
             mock.patch("main._probe_media_duration", return_value=12.0), \
             mock.patch("main._trim_media_file", side_effect=lambda path, seconds, timeout=60: path), \
             mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            plugin.generate(context)

        # 本镜 5 秒：两段 12s 音频各截断到 5s 后上传，合计 10s ≤ 官方总上限 15s
        self.assertEqual(
            media_urls(payload, "reference_audio"),
            ["https://n.uguu.se/1.mp3", "https://n.uguu.se/2.mp3"],
        )

    def test_overlong_prompt_is_reported_before_submit(self):
        payload = {}
        post, get = self._successful_gateway(payload=payload)
        buffer = io.StringIO()
        with mock.patch("main.MAX_PROMPT_CHARS", 5), \
             mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep"):
            with contextlib.redirect_stdout(buffer):
                plugin.generate(make_context(prompt="这是一段很长的分镜提示词"))

        self.assertIn("超过网关上限", buffer.getvalue())

    def test_poll_rate_limit_backs_off_interval(self):
        polls = {"count": 0}
        task_id = "rate_task"

        def post(url, **kwargs):
            return FakeResponse(202, {"taskId": task_id})

        def get(url, **kwargs):
            if url.endswith(plugin._TASKS_PATH):
                return FakeResponse(200, {"tasks": [], "hasMore": False})
            if url.endswith(f"/v1/videos/{task_id}") or url.endswith(f"/api/v1/tasks/{task_id}"):
                polls["count"] += 1
                if polls["count"] <= 2:
                    return FakeResponse(429, {"error": "rate limited"})
                return FakeResponse(200, {
                    "status": "succeeded",
                    "result": {"url": "https://cdn.example.com/result.mp4"},
                })
            if url.endswith("result.mp4"):
                return FakeResponse(200, content=MP4_SAMPLE)
            self.fail(f"unexpected GET {url}")

        with mock.patch("main.requests.post", side_effect=post), \
             mock.patch("main.requests.get", side_effect=get), \
             mock.patch("main.time.sleep") as sleep:
            files = plugin.generate(make_context())

        delays = [call.args[0] for call in sleep.call_args_list]
        self.assertEqual(delays[:3], [10, 20, 40])
        self.assertTrue(os.path.exists(files[0]))

    def test_gateway_error_hints_cover_new_documented_codes(self):
        for code, keyword in (
            ("WAN3_API_CONVERSATION_INVALID", "素材会话"),
            ("WAN3_API_MEDIA_TOO_LARGE", "体积超限"),
            ("WAN3_API_MENTIONS_INVALID", "素材引用"),
            ("WAN3_API_MEDIA_DISK_LOW", "磁盘空间"),
            ("EXTERNAL_MEDIA_URL_BLOCKED", "内网"),
            ("points_not_enough", "积分不足"),
        ):
            described = plugin._describe_api_error(f'HTTP 400 - {{"code": "{code}"}}')
            self.assertIn("提示：", described)
            self.assertIn(keyword, described)


if __name__ == "__main__":
    unittest.main(verbosity=2)
